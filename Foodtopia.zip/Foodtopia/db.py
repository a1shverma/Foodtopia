import mysql.connector
from flask_bcrypt import generate_password_hash, check_password_hash
def connectDB(host='localhost', database='Foodtopia', user='root', password='1234'):
	return mysql.connector.connect(host=host, database=database, user=user, password=password)


def disconnectDB(conn):
	conn.close()

def executeDB(conn, sql, values):
	cursor = conn.cursor()
	cursor.execute(sql, values)
	conn.commit()

def queryDB(conn,sql):
	cursor =conn.cursor()
	cursor.execute(sql)
	rows= cursor.fetchall()
	cursor.close()
	return rows

def register_user(fname,lname,email,address,password):
	c = connectDB()
	password = generate_password_hash(password)
	executeDB(c, "insert into Customer values(0, %s, %s, %s, %s, %s)", (fname, lname, email, address, password))
	disconnectDB(c)
	return True

def login_user(email, password):
	c = connectDB()
	result = queryDB(c, "select * from Customer where EmailId ='"+email+"'")
	disconnectDB(c)
	if result:
		if check_password_hash(result[0][5], password):
			return result[0]
		else:
			return False
	else:
		return False

def add_to_cart(user_id,item_id):
	c = connectDB()
	executeDB(c, "insert into cart values(%s, %s)", (user_id, item_id))
	disconnectDB(c)
	return True

def remove_from_cart(item_id):
	c = connectDB()
	executeDB(c, "remove from cart where item_id=%s" + (item_id,))
	disconnectDB(c)
	return True

def get_items(user_id):
	c = connectDB()
	result = queryDB(c, "select ItemName,ItemPrice,ItemId from Menu,cart where Menu.ItemId=cart.item_id and cart.user_id="+str(user_id))
	disconnectDB(c)
	return result

def add_order():
	pass

def get_menu_items():
	c = connectDB()
	sql = 'select * from Menu'
	result = queryDB(c,sql)
	disconnectDB(c)
	return result
