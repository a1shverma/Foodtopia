from flask import Flask, render_template, url_for,request, session,url_for, redirect
from flask_bcrypt import generate_password_hash
from db import *
app=Flask(__name__)
app.secret_key = 'super secret key'


@app.route('/')
def index():
		return render_template('index.html')

@app.route('/register', methods=('GET', 'POST'))
def register():
	if request.method=='POST':
		register_user(request.form.get('first'), request.form.get('last'), request.form.get('email'),request.form.get('address'),request.form.get('password'))
		print(request.form.get('first'), request.form.get('last'), request.form.get('email'),request.form.get('address'),request.form.get('password'))
		return redirect(url_for('index'))
	return render_template('register.html')
#Login User
@app.route('/login', methods=('GET', 'POST'))
def login():
	if request.method =='POST':
		result = login_user(request.form.get('email'), request.form.get('password'))
		session['login'] = True
		session['user_id'] = result[0]
		session['email'] = result[3]
		return redirect('/')
	return render_template('login.html')
#Logout User
@app.route('/logout')
def logout():
	session['login'] = False
	session['user_id'] = 0
	session['email'] = ''
	return redirect(url_for('index'))

@app.route('/restaurants')
def restaurants_page():
	return render_template('restaurants.html')

@app.route('/menu')
def orders_page():
	menu = get_menu_items()
	return render_template('menu.html', menu=menu)

@app.route('/checkout')
def redirect_checkout():
	return redirect('/cart')

@app.route('/order')
def order_placed():
	return render_template('order.html')

@app.route('/cart')
def checkout():
	return render_template('cart.html', items=get_items(session['user_id']))

@app.route('/add_cart/<item_id>')
def add_cart_page(item_id):
	user_id = session['user_id']
	add_to_cart(user_id,item_id)
	return 'added'


if __name__=='__main__':
	app.run(host='0.0.0.0',port=8000, debug=True)
